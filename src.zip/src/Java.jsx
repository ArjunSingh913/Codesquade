import * as React from 'react';
import Footer1 from './Footor1';
import Nav from './NavBar';
import img7 from './Assets/Images/img7.webp'
import Customor from './Assets/product/Customor';
export default function Java() {
  return (
  <>
  
  <Nav/>
 <Customor title= "Java" img= "https://i.pinimg.com/736x/23/f2/05/23f2053c05cbfbb8236dab9e85d0249f.jpg" img1={img7} 
 img2= "https://i.pinimg.com/736x/23/f2/05/23f2053c05cbfbb8236dab9e85d0249f.jpg" img3= "https://i.pinimg.com/736x/23/f2/05/23f2053c05cbfbb8236dab9e85d0249f.jpg"
 img4= "https://i.pinimg.com/736x/23/f2/05/23f2053c05cbfbb8236dab9e85d0249f.jpg" img5= "https://i.pinimg.com/736x/23/f2/05/23f2053c05cbfbb8236dab9e85d0249f.jpg"
 head="Java" head1="Courses" mentor="Mr. Manish Bhatia"
 corse1="Advance Java" corse2="Core Java" corse3="Spring Hibernate" corse4="Core With Advance Java" corse5="Java Weekend Batch"
 work="Work On Live Project"
 
 
 
 />

<Footer1/>
      

  </>
  )
}
