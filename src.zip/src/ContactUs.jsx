import React from 'react'
import Customor from './Assets/product/Customor'

export default function ContactUs() {
  return (
   <>
   <Customor/>
   </>
  )
}
