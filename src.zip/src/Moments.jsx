import React from 'react'

export default function Moments() {
  return (
    <>
    <div className='m-head__8' style={{marginBottom:"40px"}} >
    <span className='title1'>Our Lovely</span>
    <span style={{marginLeft:"15px"}}>Movements</span>
    </div>
    <div style={{position: "relative", height: "750.352px"}}>

      <div class="col-6 col-md-4 col-lg-3 grid-item" style={{position: "absolute", marginLeft: "3.5rem" ,top: "0px",width:"20rem"}}>
        <div class="card overflow-hidden">
          <div class="card-overlay-hover">
           
            <img height={"400rem"} src="https://www.pixelstalk.net/wp-content/uploads/2016/07/Wallpapers-pexels-photo.jpg" class="rounded-3" alt="course image"/>
          </div>
        </div>
      </div>

			<div class="col-6 col-md-4 col-lg-3 grid-item" style={{position: "absolute", marginLeft: "24.5rem", top: "0px",width:"20rem"}}>
				<div class="card overflow-hidden">
					<div class="card-overlay-hover ">
						
						<img height={"300rem"} src="https://www.pixelstalk.net/wp-content/uploads/2016/07/Wallpapers-pexels-photo.jpg" class="rounded-3" alt="course image"/>
					</div>
				</div>
			</div>

			<div class="col-6 col-md-4 col-lg-3 grid-item" style={{position: "absolute", marginLeft: "45.5rem", top: "0px",width:"20rem"}}>
				<div class="card overflow-hidden">
					<div class="card-overlay-hover">
						
						<img height={"400rem"} src="https://www.pixelstalk.net/wp-content/uploads/2016/07/Wallpapers-pexels-photo.jpg" class="rounded-3" alt="course image"/>
					</div>
				</div>
			</div>
			
			<div class="col-6 col-md-4 col-lg-3 grid-item" style={{position: "absolute", left: "24.5rem", top: "20rem",width:"20rem"}}>
				<div class="card overflow-hidden">
					<div class="card-overlay-hover">
						
						<img height={"400rem"} src="https://www.pixelstalk.net/wp-content/uploads/2016/07/Wallpapers-pexels-photo.jpg" class="rounded-3" alt="course image"/>
					</div>
				</div>
			</div>

			<div class="col-6 col-md-4 col-lg-3 grid-item" style={{position: "absolute", left: "3.5rem", top: "420.575px",width:"20rem"}}>
				<div class="card overflow-hidden">
					<div class="card-overlay-hover">
					
						<img height={"300rem"} src="https://www.pixelstalk.net/wp-content/uploads/2016/07/Wallpapers-pexels-photo.jpg" class="rounded-3" alt="course image"/>
					</div>
				</div>
			</div>

			<div class="col-6 col-md-4 col-lg-3 grid-item" style={{position: "absolute", left: "45.5rem" ,top: "420.575px",width:"20rem"}}>
				<div class="card overflow-hidden">
					<div class="card-overlay-hover">
						
						<img height={"300rem"} src="https://www.pixelstalk.net/wp-content/uploads/2016/07/Wallpapers-pexels-photo.jpg" class="rounded-3" alt="course image"/>
					</div>
				</div>
			</div>

			<div class="col-6 col-md-4 col-lg-3 grid-item" style={{position: "absolute", left: "66.5rem", top: "0px",width:"20rem"}}>
				<div class="card overflow-hidden">
					<div class="card-overlay-hover">
						
						<img height={"300rem"}  src="https://www.pixelstalk.net/wp-content/uploads/2016/07/Wallpapers-pexels-photo.jpg" class="rounded-3" alt="course image"/>
					</div>
				</div>
			</div>
			
			<div class="col-6 col-md-4 col-lg-3 grid-item" style={{position: "absolute", left: "66.5rem", top: "20rem",width:"20rem"}}>
				<div class="card overflow-hidden">
					<div class="card-overlay-hover">
					
						<img height={"400rem"}  src="https://www.pixelstalk.net/wp-content/uploads/2016/07/Wallpapers-pexels-photo.jpg" class="rounded-3" alt="course image"/>
					</div>
					
					
				</div>
			</div>
		</div>
    </>
  )
}
