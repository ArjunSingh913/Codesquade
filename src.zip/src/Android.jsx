import React from 'react'
import Customor from './Assets/product/Customor'
import image from './Assets/Images/cs5.png'
import Nav from './NavBar'
import Footor1 from './Footor1'
export default function Android() {
  return (
   <>
   <Nav/>
   <Customor title="Android"
   img1={image}
img="https://1.bp.blogspot.com/-GykUckY6bNQ/W-lXkhBi4YI/AAAAAAAAAKg/N1hVeDeo92kMdkCxNLFDpNJRW08PGa3LACLcBGAs/s1600/IMG_20181112_183456.png"
img2= "https://1.bp.blogspot.com/-GykUckY6bNQ/W-lXkhBi4YI/AAAAAAAAAKg/N1hVeDeo92kMdkCxNLFDpNJRW08PGa3LACLcBGAs/s1600/IMG_20181112_183456.png" img3= "https://1.bp.blogspot.com/-GykUckY6bNQ/W-lXkhBi4YI/AAAAAAAAAKg/N1hVeDeo92kMdkCxNLFDpNJRW08PGa3LACLcBGAs/s1600/IMG_20181112_183456.png"
 img4= "https://1.bp.blogspot.com/-GykUckY6bNQ/W-lXkhBi4YI/AAAAAAAAAKg/N1hVeDeo92kMdkCxNLFDpNJRW08PGa3LACLcBGAs/s1600/IMG_20181112_183456.png" img5= "https://1.bp.blogspot.com/-GykUckY6bNQ/W-lXkhBi4YI/AAAAAAAAAKg/N1hVeDeo92kMdkCxNLFDpNJRW08PGa3LACLcBGAs/s1600/IMG_20181112_183456.png"
   corse1="Best Android Course" corse2="Get Real Time Experiance" corse3="Android Corse With Training" corse4="Learn Basic Android" 
    corse5="Android Weekend Batch" 
    head="Android" head1="Courses" mentor="Mr. Manish Bhatia"
    work="Work On Live Project"
    />
    <Footor1/>
   </>
  )
}
